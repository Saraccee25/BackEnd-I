package com.dh.Clase15_SpringMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase15SpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
