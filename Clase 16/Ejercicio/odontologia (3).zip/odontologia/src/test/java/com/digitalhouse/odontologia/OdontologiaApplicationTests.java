package com.digitalhouse.odontologia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
